export const globalStyles = {
    ContainerTitle: {
        fontWeight: 'bold'
    }
}