export default {
    xs: 'xs',
    sm: 'sm',
    md: 'md',
    lg: 'lg',
}