export const ENUM_FORM_TYPE = {
    CREATE: 1,
    UPDATE: 2,
    READ_ONLY: 3
}